package com.abnamro.apps.referenceandroid

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.Espresso.openActionBarOverflowOrOptionsMenu
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withContentDescription
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.platform.app.InstrumentationRegistry
import org.hamcrest.CoreMatchers.allOf

class MainRobot {
    fun checkHelloWorldIsVisible() {
        onView(withText("Hello World!")).check(matches(isDisplayed()))
    }

    fun clickFab() {
        onView(withId(R.id.fab)).perform(click())
    }

    fun checkSnackbarText(text: String) {
        // Increase reliability by searching specifically for the Snackbar's internal text ID
        onView(withId(com.google.android.material.R.id.snackbar_text))
            .check(matches(withText(text)))
    }

    fun openMenu() {
        try {
            openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getInstrumentation().targetContext)
        } catch (e: Exception) {
            // Fallback for some configurations where the above method fails, 
            // specifically searching for the standard "More options" description.
            onView(withContentDescription("More options")).perform(click())
        }
    }

    fun checkMenuOptionVisible(option: String) {
        onView(withText(option)).check(matches(isDisplayed()))
    }
}
