package com.abnamro.apps.referenceandroid

import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
@LargeTest
class ExampleInstrumentedTest {
    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    private val robot = MainRobot()

    @Test
    fun testHelloWorldIsDisplayed() {
        robot.checkHelloWorldIsVisible()
    }

    @Test
    fun testFabClickShowsSnackbar() {
        robot.clickFab()
        robot.checkSnackbarText("Replace with your own action")
    }

    @Test
    fun testSettingsMenuIsVisible() {
        robot.openMenu()
        robot.checkMenuOptionVisible("Settings")
    }
}